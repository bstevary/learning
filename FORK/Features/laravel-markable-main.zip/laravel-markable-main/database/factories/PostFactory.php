<?php

namespace Maize\Markable\Database\Factories;

use Illuminate\Database\Eloquent\Factories\Factory;
use Maize\Markable\Tests\Models\Post;

class PostFactory extends Factory
{
    protected $model = Post::class;

    public function definition()
    {
        return [

        ];
    }
}
