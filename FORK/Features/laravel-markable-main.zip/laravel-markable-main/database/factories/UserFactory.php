<?php

namespace Maize\Markable\Database\Factories;

use Illuminate\Database\Eloquent\Factories\Factory;
use Maize\Markable\Tests\Models\User;

class UserFactory extends Factory
{
    protected $model = User::class;

    public function definition()
    {
        return [

        ];
    }
}
