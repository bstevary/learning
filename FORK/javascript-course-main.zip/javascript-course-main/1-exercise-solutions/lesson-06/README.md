# Exercises
![Exercises 6](https://user-images.githubusercontent.com/70604577/229873905-708dc9a1-2874-4732-a652-2173fa3a6abb.png)
![Exercises 6 2](https://user-images.githubusercontent.com/70604577/229873900-30e91e01-4f62-49b7-8b57-5344f54d9805.png)
![Exercises 6 3](https://user-images.githubusercontent.com/70604577/229873902-1699b853-3c6e-4726-b473-46a7147146aa.png)
![Exercises 6 4](https://user-images.githubusercontent.com/70604577/229873904-35c1167b-afc6-44fc-a031-ff1c76c7edb0.png)
