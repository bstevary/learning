# Exercises
![Exercises 7](https://user-images.githubusercontent.com/70604577/229874039-024954e1-51f9-49b8-970c-889cb73cc763.png)
![Exercises 7 2](https://user-images.githubusercontent.com/70604577/229874034-96435582-d769-44ee-ad12-cfd9da855bc1.png)
![Exercises 7 3](https://user-images.githubusercontent.com/70604577/229874037-5b15fd2f-c466-4714-a0e2-e1e60130fb8d.png)
