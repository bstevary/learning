alert('hello');
alert('Good job!');

2 + 2
10 - 3

document.body.innerHTML = 'hello';